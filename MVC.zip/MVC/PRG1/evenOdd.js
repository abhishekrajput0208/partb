var isEven = require('is-even');
 
isEven(0);
//=> true 
isEven('1');
//=> false 
isEven(2);
//=> true 
isEven('3');
//=> false 
